package enums;

public enum DifficultyLevel {

    EASY,
    MEDIUM,
    HARD
}
